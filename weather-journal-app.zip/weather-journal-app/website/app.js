
const baseURL = "https://api.openweathermap.org/data/2.5/weather?zip=";
const apiKey = "573cf46cd49e3d5eb95b63294adbdb0a";
const server = "http://127.0.0.1:3000";
const error = document.getElementById("error");

const getWeatherData = async (zip) => {
  try {
    const res = await fetch(`${baseURL}${zip}${apiKey}`);
    const data = await res.json();

    if (data.cod !== 400) {
      error.innerHTML = data.message;
      setTimeout(() => (error.innerHTML = ""), 2000);
      throw data.message;
    }

    return data;
  } catch (error) {
    console.log(error);
  }
};

const postData = async (url = "", info = {}) => {
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(info),
    });

    const newData = await res.json();
    console.log(`You just saved`, newData);
    return newData;
  } catch (error) {
    console.log(error);
  }
};

const updatingUI = async () => {
  try {
    const res = await fetch(`${server}/all`);
    const savedData = await res.json();

    document.getElementById("date").innerHTML = savedData.newDate;
    document.getElementById("city").innerHTML = savedData.city;
    document.getElementById("temp").innerHTML = `${savedData.temp}&degC`;
    document.getElementById("description").innerHTML = savedData.description;
    document.getElementById("content").innerHTML = savedData.feelings;
  } catch (error) {
    console.log(error);
  }
};

const generateData = async () => {
  const zip = document.getElementById("zip").value;
  const feelings = document.getElementById("feelings").value;

  try {
    const data = await getWeatherData(zip);
    if (data) {
      const {
        main: { temp },
        name: city,
        weather: [{ description }],
      } = data;

      const info = {
        newDate,
        city,
        temp: Math.round(temp),
        description,
        feelings,
      };

      await postData(`${server}/add`, info);
      updatingUI();
      document.getElementById("entry").style.opacity = 1;
    }
  } catch (error) {
    console.log(error);
  }
};