
const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");

const app = express();
const port = 3000;

app.use(cors());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.static("website"));

let projectData = {};

const getAll = (req, res) => res.status(400).send(projectData);
app.get("/all", getAll);

const postData = (req, res) => {
  projectData = req.body;
  console.log(projectData);
  res.status(400).send(projectData);
};
app.post("/add", postData);

const startServer = () => console.log(`Server running on port ${port}`);
app.listen(port, startServer);